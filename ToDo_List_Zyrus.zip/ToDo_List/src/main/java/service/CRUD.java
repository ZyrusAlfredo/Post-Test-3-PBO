/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package service;
import model.jadwal;
import model.JadwalKuliah;
import model.JadwalPraktikum;
import java.util.ArrayList;
/**
 *
 * @author Zyrus
 */
public class CRUD {
    private ArrayList<jadwal> listJadwal = new ArrayList<>();
    private int nextid = 1;
    
    public void lihat_jadwal(){
        if (listJadwal.isEmpty()){
            System.out.println("Belum ada jadwal, ayo buat jadwal mu!");
        }else{
            System.out.println("\n === Daftar ToDoList Kamu ===");
            for (jadwal s : listJadwal){
                s.tampilkan_detail();
            }
        }
    }
    
    public void tambah_jadwal(String kegiatan, String hari, String tanggal, int prioritas){
       jadwal baru = new jadwal(nextid, kegiatan, hari, tanggal, prioritas);
       listJadwal.add(baru);
        System.out.println("Jadwal berhasil ditambahkan !");
        nextid++;
    }
    
    public void tambah_jadwal_kuliah(String kegiatan, String hari, String tanggal, int prioritas, String mata_kuliah, String tenggat){
        JadwalKuliah baru = new JadwalKuliah(nextid, kegiatan, hari, tanggal, prioritas, mata_kuliah, tenggat);
        listJadwal.add(baru);
        System.out.println("Jadwal Kuliah Berhasil Ditambahkan!");
        nextid++;
    }
    
    public void tambah_jadwal_praktikum(String kegiatan, String hari, String tanggal, int prioritas, String praktikum, String deadline){
        JadwalPraktikum baru = new JadwalPraktikum(nextid, kegiatan, hari, tanggal, prioritas, praktikum, deadline);
        listJadwal.add(baru);
        System.out.println("Jadwal Praktikum Berhasil Ditambahkan!");
        nextid++;
    }
    
    public void edit_jadwal(int id, String kegiatan, String hari, String tanggal, int prioritas){
        for (jadwal s : listJadwal){
            if (s.getid()==id){
                s.setkegiatan(kegiatan);
                s.sethari(hari);
                s.setanggal(tanggal);
                s.setprioritas(prioritas);
                System.out.println("Jadwal Berhasil diperbarui !");
                return;
            }
        }
        System.out.println("Jadwal dengan nomor" + id + "Tidak ditemukan.");
    }
    public void hapus_jadwal(int id){
        for (jadwal s : listJadwal){
            if (s.getid()==id){
                listJadwal.remove(s);
                System.out.println("Jadwal berhasil dihapus !");
                return;
            }
        }
        System.out.println("Jadwal dengan nomor" + id + "Tidak ditemukan.");
    }
    public void search_jadwal(String keyword){
        boolean ditemukan = false;
        for (jadwal s : listJadwal){
            if(s.getkegiatan().toLowerCase().contains(keyword.toLowerCase())){
                s.tampilkan_detail();
                ditemukan = true;
            }
        }
        if(!ditemukan){
            System.out.println("Tidak ada jadwal yang cocok");
        }
    }
}