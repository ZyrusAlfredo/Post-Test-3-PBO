/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

/**
 *
 * @author Zyrus
 */
public class JadwalPraktikum extends jadwal {
    private String praktikum;
    private String deadline;

    public JadwalPraktikum(int id, String kegiatan, String hari, String tanggal, int prioritas, String praktikum, String deadline){
        super(id, kegiatan, hari, tanggal, prioritas);
        this.praktikum = praktikum;
        this.deadline = deadline;
    }
        
    public String getpraktikum(){return praktikum;}
    public void setpraktikum(String praktikum){this.praktikum = praktikum;}
    
    public String getdeadline(){return deadline;}
    public void setdeadline(String deadline){this.deadline = deadline;}
    
    @Override
    public void tampilkan_detail(){
        super.tampilkan_detail();
        System.out.println("Praktikum: " + praktikum);
        System.out.println("Deadline: " + deadline);
    }
}
