/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

/**
 *
 * @author Zyrus
 */
public class JadwalKuliah extends jadwal {
    private String mata_kuliah;
    private String tenggat;    

    public JadwalKuliah(int id, String kegiatan, String hari, String tanggal, int prioritas, String mata_kuliah, String tenggat) {
        super(id, kegiatan, hari, tanggal, prioritas);
        this.mata_kuliah = mata_kuliah;
        this.tenggat = tenggat;
    }
    
    public String getmata_kuliah() {return mata_kuliah;}
    public void setmata_kuliah(String mata_kuliah){this.mata_kuliah = mata_kuliah;}
    
    public String gettenggat() {return tenggat;}
    public void settenggat(String tenggat){this.tenggat = tenggat;}
    
    @Override
    public void tampilkan_detail(){
        super.tampilkan_detail();
        System.out.println("Mata Kuliah: " + mata_kuliah);
        System.out.println("Tenggat: " + tenggat);
    }
}
